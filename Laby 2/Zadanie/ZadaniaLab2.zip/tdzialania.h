#ifndef TDZIALANIA_H
#define TDZIALANIA_H

class Tdzialania{
    private:
        int a,b;
    public:
        void podajDane();
        int suma();
        int roznica();
        int iloczyn();
        float iloraz();
        long double potega();
        void wyswietl();
};
#endif